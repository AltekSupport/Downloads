rundll32 printui.dll,PrintUIEntry /q /dl /n TE_Sales

(New-Object System.Net.WebClient).DownloadFile("https://www.support.xerox.com/support/workcentre-7800-series/file-redirect/engb.html?operatingSystem=win10x64&fileLanguage=en_GB&&associatedProduct=WorkCentre-78xx-built-in%20controller&contentId=138486", "$env:TEMP/XeroxWorkCentre78XX_6.159.10.0_PS_x64.zip")

Expand-Archive "$env:TEMP\XeroxWorkCentre78XX_6.159.10.0_PS_x64.zip" -DestinationPath "C:\ABS\XeroxWorkCentre78XX_6.159.10.0_PS_x64" -Force

$portName = "IP_192.168.168.50"
$portExists = Get-Printerport -Name $portname -ErrorAction SilentlyContinue
if (-not $portExists) {
  Add-PrinterPort -name $portName -PrinterHostAddress "192.168.168.50"
}

rundll32 printui.dll,PrintUIEntry /if /b "TE_Sales" /f C:\abs\XeroxWorkCentre78XX_6.159.10.0_PS_x64\XeroxWorkCentre78XX_PS.inf /r "IP_192.168.168.50" /m "Xerox WorkCentre 7845 V4 PS"
TIMEOUT /T 30